#pragma once

#include "IStorage.h"
#include <string>
#include <unordered_map>

class FileStorage : public IStorage {
public:
    explicit FileStorage(std::string base_path);
    ~FileStorage() override = default;

    FileStorage(const FileStorage&) = delete;
    auto operator=(const FileStorage&) -> FileStorage& = delete;
    FileStorage(FileStorage&&) = delete;
    auto operator=(FileStorage&&) -> FileStorage& = delete;

    [[nodiscard]] auto loadFleet() -> std::vector<Vehicle> override;
    auto saveFleet(const std::vector<Vehicle>& fleet) -> void override;

    auto appendRecord(const Record& record) -> void override;
    [[nodiscard]] auto getRecordRange(uint32_t vehicle_id, size_t offset, size_t limit) -> std::vector<Record> override;
    auto deleteRecords(uint32_t vehicle_id) -> void override;

    auto saveActiveRentals(const std::unordered_map<std::string, RentalSession>& rentals) -> void override;
    [[nodiscard]] auto loadActiveRentals() -> std::unordered_map<std::string, RentalSession> override;

private:
    std::string base_path_;

    [[nodiscard]] static auto serializeVehicle(const Vehicle& vehicle) -> std::string;
    [[nodiscard]] static auto deserializeVehicle(const std::string& line) -> std::optional<Vehicle>;
    
    [[nodiscard]] static auto serializeRecord(const Record& record) -> std::string;
    [[nodiscard]] static auto deserializeRecord(const std::string& line) -> std::optional<Record>;
};